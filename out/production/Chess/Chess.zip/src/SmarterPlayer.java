import java.util.*;
import java.awt.*;
/**
 * A smarter version of player
 *
 * @author David Feng
 * @version 29 May 2018
 */
public class SmarterPlayer extends Player
{

  /**
   * Constructs a Smarter Player object
   * @param b the board
   * @param s the name of the player
   * @param c the color of the player
   */
  public SmarterPlayer(Board b, String s, Color c)
  {
    super(b, s, c);
  }

  /**
   * Gets the next move of the player
   * @return  the next move
   */
  public Move nextMove()
  {
    int highestMean = Integer.MIN_VALUE;
    int index = 0;
    ArrayList<Move> arr = board.allMoves(color);
    for(int i = 0; i < arr.size(); i++)
    {
      board.executeMove(arr.get(i));
      int temp = valueOfMeanestResponse();
      board.undoMove(arr.get(i));
      if(temp > highestMean)
      {
        highestMean = temp;
        index = i;
      }
    }
    if(index == 0)
    {
      return arr.get((int) (Math.random() * arr.size()));
    }
    return arr.get(index);
  }

  /**
   * Calculates the difference in scores after move
   * @param move  the move to be executed
   * @return  the difference in scores
   */
  public int calculateDiffScore(Move move)
  {
    board.executeMove(move);
    int myScore = calculateScore(color);
    int theirScore;
    if(color.equals(Color.BLACK))
    {
      theirScore = calculateScore(Color.WHITE);
    }
    else
    {
      theirScore = calculateScore(Color.BLACK);
    }
    board.undoMove(move);
    return myScore - theirScore;
  }

  /**
   * Calculates the difference in scores in the status quo
   * @return  the difference in scores
   */
  public int calculateDiffScore()
  {
    int myScore = calculateScore(color);
    int theirScore = calculateScore(otherColor(color));
    return myScore - theirScore;
  }

  /**
   * Calculates the score of the color
   * @param c the color to be calculated
   * @return  the score of that color
   */
  public int calculateScore(Color c)
  {
    int sum = 0;
    for(int i = 0; i < 8; i++)
    {
      for(int j = 0; j < 8; j++)
      {
        Piece p = board.get(new Location(i, j));
        if(p != null && p.getColor().equals(c))
        {
          sum += p.getValue();
        }
      }
    }
    return sum;
  }

  /**
   * Calculates the value of the meanest response possible from the other player
   *
   * @return  the value of the meanest response
   */
  private int valueOfMeanestResponse()
  {
    ArrayList<Move> arr = board.allMoves(otherColor(color));
    int meanest = Integer.MAX_VALUE;
    for(int i = 0; i < arr.size(); i++)
    {
      board.executeMove(arr.get(i));
      int score = calculateDiffScore();
      board.undoMove(arr.get(i));
      if(score < meanest)
      {
        score = meanest;
      }
    }
    return meanest;
  }

  /**
   * Gets the other color that is not c
   * @param c the color that is being tested
   * @return  the opposite color of c
   */
  private Color otherColor(Color c)
  {
    if(c.equals(Color.WHITE))
    {
      return Color.BLACK;
    }
    else
    {
      return Color.WHITE;
    }
  }

}
