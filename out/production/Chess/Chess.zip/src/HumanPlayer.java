import java.awt.Color;
import java.util.*;

/**
 * Represents a human player amongst the players
 *
 * @author DavidFeng
 * @version 29 May 2018
 */
public class HumanPlayer extends Player
{
  public BoardDisplay display;

  /**
   * Constructs a Human Player object
   * @param b the board
   * @param s the name
   * @param c the color
   * @param display the display for the board
   */
  public HumanPlayer(Board b, String s, Color c, BoardDisplay display)
  {
    super(b, s, c);
    this.display = display;
  }

  /**
   * Gets the next move of the HumanPlayer
   * @return  the next move
   */
  public Move nextMove()
  {
    Move move = display.selectMove();
    while(!isLegal(move))
    {
      move = display.selectMove();
    }
    return move;
  }

  /**
   * Checks if a move is legal
   * @param move  the move to be checked
   * @return  true  if the move is legal
   *          false otherwise
   */
  private boolean isLegal(Move move)
  {
    ArrayList<Move> arr = board.allMoves(color);
    for(int i = 0; i < arr.size(); i++)
    {
      if(move.equals(arr.get(i)))
      {
        return true;
      }
    }
    return false;
  }
}
