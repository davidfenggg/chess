import java.util.*;
import java.awt.*;
/**
 * A smarter version of player
 *
 * @author David Feng
 * @version 29 May 2018
 */
public class SmartPlayer extends Player
{

  /**
   * Constructs a Smart Player object
   * @param b the board
   * @param s the name of the player
   * @param c the color of the player
   */
  public SmartPlayer(Board b, String s, Color c)
  {
    super(b, s, c);
  }

  /**
   * Gets the next move of the player
   * @return  the next move
   */
  public Move nextMove()
  {
    ArrayList<Move> moves = board.allMoves(color);
    ArrayList<Integer> scores = new ArrayList<Integer>();
    for(int i = 0; i < moves.size(); i++)
    {
      scores.add(calculateDiffScore(moves.get(i)));
    }
    int maxIndex = 0;
    for(int i = 0; i < scores.size(); i++)
    {
      if(scores.get(i) > scores.get(maxIndex))
      {
        maxIndex = i;
      }
    }
    if(maxIndex == 0)
    {
      int x = (int) (Math.random() * scores.size());
      return moves.get(x);
    }
    return moves.get(maxIndex);
  }

  /**
   * Calculates the difference in scores after move
   * @param move  the move to be executed
   * @return  the difference in scores
   */
  public int calculateDiffScore(Move move)
  {
    board.executeMove(move);
    int myScore = calculateScore(color);
    int theirScore;
    if(color.equals(Color.BLACK))
    {
      theirScore = calculateScore(Color.WHITE);
    }
    else
    {
      theirScore = calculateScore(Color.BLACK);
    }
    board.undoMove(move);
    return myScore - theirScore;
  }

  /**
   * Calculates the difference in scores in the status quo
   * @return  the difference in scores
   */
  public int calculateDiffScore()
  {
    int myScore = calculateScore(color);
    int theirScore = calculateScore(otherColor(color));
    return myScore - theirScore;
  }

  /**
   * Calculates the score of the color
   * @param c the color to be calculated
   * @return  the score of that color
   */
  public int calculateScore(Color c)
  {
    int sum = 0;
    for(int i = 0; i < 8; i++)
    {
      for(int j = 0; j < 8; j++)
      {
        Piece p = board.get(new Location(i, j));
        if(p != null && p.getColor().equals(c))
        {
          sum += p.getValue();
        }
      }
    }
    return sum;
  }


  /**
   * Gets the other color that is not the player's color
   * @param c the current player color
   * @return  the other color
   */
  private Color otherColor(Color c)
  {
    if(c.equals(Color.WHITE))
    {
      return Color.BLACK;
    }
    else
    {
      return Color.WHITE;
    }
  }

}
